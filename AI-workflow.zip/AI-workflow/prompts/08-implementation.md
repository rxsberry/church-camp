# 08 Implementation Prompt

다음 기준에 따라 최종 구현을 수행하라.

* Node.js 기반 워크플로 스크립트 작성
* 산출 마크다운 생성
* 시연용 프론트엔드 구현
* 정확한 외부 링크 연결
* 한국어 카피 유지
* 밝고 아동 친화적인 UI 반영
* Google Sheets / Apps Script 저장 구조 설명 문서 추가

과장된 백엔드나 프레임워크는 사용하지 말라.
