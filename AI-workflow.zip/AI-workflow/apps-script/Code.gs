const SHEET_NAMES = {
  registrations: "신청자명단",
  teams: "조편성",
  volunteers: "봉사자명단",
  scheduleNotes: "일정메모",
  reflections: "소감문",
  prayerRequests: "기도제목"
};

function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu("캠프 워크플로")
    .addItem("시트 초기화", "initCampSheets")
    .addItem("조 편성 생성", "buildTeamsFromRegistrations")
    .addToUi();
}

function initCampSheets() {
  getOrCreateSheet_(SHEET_NAMES.registrations, [
    "제출시간",
    "이름",
    "학년",
    "보호자이름",
    "연락처",
    "특이사항"
  ]);

  getOrCreateSheet_(SHEET_NAMES.teams, [
    "조이름",
    "이름",
    "학년"
  ]);

  getOrCreateSheet_(SHEET_NAMES.volunteers, [
    "제출시간",
    "이름",
    "역할",
    "연락처",
    "특이사항"
  ]);

  getOrCreateSheet_(SHEET_NAMES.scheduleNotes, [
    "제출시간",
    "제목",
    "내용",
    "담당자"
  ]);

  getOrCreateSheet_(SHEET_NAMES.reflections, [
    "제출시간",
    "이름",
    "내용"
  ]);

  getOrCreateSheet_(SHEET_NAMES.prayerRequests, [
    "제출시간",
    "이름",
    "분류",
    "내용"
  ]);
}

function doGet() {
  return ContentService
    .createTextOutput(JSON.stringify({
      ok: true,
      message: "Church camp workflow backend is running."
    }))
    .setMimeType(ContentService.MimeType.JSON);
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents || "{}");
    const type = payload.type || "registration";

    if (type === "registration") {
      appendRegistration(payload);
    } else if (type === "reflection") {
      appendReflection(payload);
    } else if (type === "prayer") {
      appendPrayerRequest(payload);
    } else {
      throw new Error("지원하지 않는 요청 타입입니다.");
    }

    return jsonResponse({
      ok: true,
      type,
      message: "저장이 완료되었습니다."
    });
  } catch (error) {
    return jsonResponse({
      ok: false,
      message: error.message
    });
  }
}

function appendRegistration(data) {
  const sheet = getOrCreateSheet_(SHEET_NAMES.registrations, [
    "제출시간",
    "이름",
    "학년",
    "보호자이름",
    "연락처",
    "특이사항"
  ]);

  sheet.appendRow([
    new Date(),
    data.studentName || "",
    data.grade || "",
    data.guardianName || "",
    data.phone || "",
    data.notes || ""
  ]);
}

function appendReflection(data) {
  const sheet = getOrCreateSheet_(SHEET_NAMES.reflections, [
    "제출시간",
    "이름",
    "내용"
  ]);

  sheet.appendRow([
    new Date(),
    data.studentName || "",
    data.content || ""
  ]);
}

function appendPrayerRequest(data) {
  const sheet = getOrCreateSheet_(SHEET_NAMES.prayerRequests, [
    "제출시간",
    "이름",
    "분류",
    "내용"
  ]);

  sheet.appendRow([
    new Date(),
    data.name || "",
    data.category || "",
    data.content || ""
  ]);
}

function buildTeamsFromRegistrations() {
  initCampSheets();
  const registrations = getOrCreateSheet_(SHEET_NAMES.registrations, []);
  const teams = getOrCreateSheet_(SHEET_NAMES.teams, [
    "조이름",
    "이름",
    "학년"
  ]);

  const values = registrations.getDataRange().getValues();
  if (values.length <= 1) {
    return;
  }

  teams.clearContents();
  teams.appendRow(["조이름", "이름", "학년"]);

  const rows = values.slice(1);
  rows.forEach((row, index) => {
    const teamNumber = (index % 4) + 1;
    teams.appendRow([`다니엘 ${teamNumber}조`, row[1], row[2]]);
  });
}

function getOrCreateSheet_(name, header) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sheet = ss.getSheetByName(name);

  if (!sheet) {
    sheet = ss.insertSheet(name);
  }

  if (header.length > 0 && sheet.getLastRow() === 0) {
    sheet.appendRow(header);
  }

  return sheet;
}

function jsonResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}
