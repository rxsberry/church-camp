# USER_MANUAL.md

## 1. 개요

이 문서는 `ai-workflow-church-camp` 프로젝트를 열고, 워크플로를 실행하고, 산출물을 확인하고, 시연용 프론트엔드와 Google Sheets / Apps Script 구조를 이해하는 방법을 설명한다.

## 2. 프로젝트 열기

1. 터미널에서 프로젝트 폴더로 이동한다.
2. `ai-workflow-church-camp` 폴더가 루트인지 확인한다.
3. 아래 명령으로 파일 구성을 확인한다.

```bash
ls
```

문서 파일과 `agents`, `prompts`, `src`, `output`, `website`, `apps-script` 폴더가 보이면 정상이다.

## 3. 워크플로 실행 방법

프로젝트 루트에서 다음 명령을 실행한다.

```bash
npm start
```

실행이 완료되면 터미널에 단계별 생성 완료 메시지와 최종 요약이 출력된다.

## 4. 생성 결과 확인 위치

워크플로 실행 후 주요 산출물은 `output/` 폴더에서 확인한다.

* `01-research-summary.md`: 요구 사항 조사 요약
* `02-generated-prd.md`: 생성된 PRD 산출 버전
* `03-prd-reflection-report.md`: PRD 반성 보고서
* `04-generated-workflow.md`: 생성된 워크플로 산출 버전
* `05-workflow-reflection-report.md`: 워크플로 반성 보고서
* `06-generated-website-prompt.md`: 시연용 프론트엔드 생성 지침
* `07-website-check-report.md`: 최종 검증 보고서
* `08-final-submission-note.md`: 제출 메모

## 5. 시연용 프론트엔드 열기

시연용 프론트엔드는 `website/index.html` 파일을 브라우저에서 열면 된다. 정적 파일 구조이므로 별도의 서버 없이 확인 가능하다.

주의:

* 이 화면은 workflow의 예시 output이다.
* 별도의 홈페이지 과제를 대체한다고 설명하면 안 된다.

## 6. Google Sheets / Apps Script 사용 방법

이 저장소는 실제 Google 계정 자원까지 자동으로 만들지 않는다. 대신 아래 자료를 제공한다.

* `BACKEND_PLAN.md`
* `DATA_FLOW.md`
* `apps-script/Code.gs`
* `apps-script/appsscript.json`

사용 절차는 다음과 같다.

1. Google Spreadsheet 하나를 만든다.
2. 시트 탭을 `registrations`, `teams`, `volunteers`, `reflections`, `prayer_requests` 등으로 만든다.
3. Spreadsheet에서 Apps Script를 열고 `apps-script/Code.gs` 내용을 붙여 넣는다.
4. 스크립트를 Web App으로 배포한다.
5. 발급된 Web App URL을 프론트 입력 폼 또는 별도 서비스에 연결한다.

## 7. 얼마나 수동으로 만들어야 하는가

모든 도구마다 Google Form과 Sheet를 따로 만들 필요는 없다. 과제용으로는 아래처럼 최소화하는 것이 적절하다.

* Spreadsheet 1개
* Apps Script 프로젝트 1개
* 실제 입력 폼 1~3개

권장 최소 구성:

* 신청 정보 입력 1개
* 소감문 입력 1개
* 기도제목 입력 1개

나머지는 시트의 다른 탭과 Apps Script 후처리로 설명할 수 있다.

## 8. 링크 수정 방법

링크를 수정해야 할 경우 다음 파일을 함께 확인한다.

* `src/utils.js`
* `website/script.js`

링크를 변경했다면 `npm run validate`를 다시 실행해 검증 보고서를 갱신한다.

## 9. 제출 준비 방법

제출 전에 아래 순서대로 확인한다.

1. `npm start` 실행
2. `output/07-website-check-report.md` 확인
3. `website/index.html` 직접 열어 시연용 output 확인
4. `BACKEND_PLAN.md`와 `DATA_FLOW.md` 확인
5. `apps-script/Code.gs` 존재 확인
6. 전체 폴더를 압축하여 제출

## 10. 주의 사항

* 본 프로젝트는 실제 AI API 호출 없이 동작한다.
* Google 자원 생성과 배포는 계정 소유자가 수동으로 해야 한다.
* 자동 생성 산출물은 수업 제출용 구조를 보여 주기 위한 것이다.
* 구현 범위를 넘어서는 기능을 포함했다고 설명하지 않는다.
