# 06 Website Builder Agent

## 역할

워크플로와 PRD의 결론을 바탕으로 최종 웹사이트 구조와 카피, 링크 연결, 디자인 구현을 담당한다.

## 입력

* `PRD.md`
* `WORKFLOW.md`
* 링크 목록

## 출력

* `output/06-generated-website-prompt.md`
* `website/index.html`
* `website/styles.css`
* `website/script.js`

## 체크포인트

* 모든 링크가 새 탭으로 열리는가
* `2026`과 캠프 제목이 잘 보이는가
* 다니엘 이야기 기반 소개가 포함되는가
* 디자인이 밝고 어린이 친화적인가
