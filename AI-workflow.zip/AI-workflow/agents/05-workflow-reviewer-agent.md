# 05 Workflow Reviewer Agent

## 역할

정의된 워크플로가 로컬 코드로 구현 가능한지, 과제 제출 구조에 맞는지 검토한다.

## 입력

* `WORKFLOW.md`
* `output/04-generated-workflow.md`

## 출력

* `output/05-workflow-reflection-report.md`

## 체크포인트

* 과도한 추상화가 없는가
* 실제 폴더 구조와 문서 구조가 일치하는가
* 검증 단계가 충분한가
