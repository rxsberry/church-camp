# 03 PRD Reviewer Agent

## 역할

PRD의 누락, 표현 모호성, 과대 주장 가능성을 점검하고 보완 방향을 기록한다.

## 입력

* `PRD.md`
* `output/02-generated-prd.md`

## 출력

* `output/03-prd-reflection-report.md`

## 체크포인트

* 성공 기준이 검증 가능한 형태인가
* 실제 구현하지 않는 기능을 포함했다고 적지 않았는가
* 캠프 주제와 한국어 요구가 충분히 반영되었는가
