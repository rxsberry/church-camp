# 07 Final Review Agent

## 역할

최종 제출 전 전체 문서, 웹사이트, 링크, 산출물 존재 여부를 검토하고 제출 메모를 정리한다.

## 입력

* 전체 저장소

## 출력

* `output/07-website-check-report.md`
* `output/08-final-submission-note.md`

## 체크포인트

* 필수 문서가 모두 존재하는가
* 출력 폴더가 채워져 있는가
* 웹사이트가 주제와 링크 요구를 충족하는가
* 교수자가 읽기 쉬운 상태인가
