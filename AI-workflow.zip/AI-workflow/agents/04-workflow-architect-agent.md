# 04 Workflow Architect Agent

## 역할

PRD를 기반으로 실제 저장소 구조와 산출물 순서를 갖춘 AI 워크플로를 정의한다.

## 입력

* `PRD.md`
* `output/01-research-summary.md`

## 출력

* `WORKFLOW.md`
* `output/04-generated-workflow.md`

## 체크포인트

* 단계 순서가 강의 구조와 일치하는가
* 각 단계에 입력과 출력이 모두 있는가
* 웹사이트 단계가 워크플로 내부에 포함되어 있는가
