# WORKFLOW-CODING.md

## 1. 문서 목적

이 문서는 `WORKFLOW.md`에서 정의한 개념적 흐름을 실제 코드 구조로 어떻게 옮겼는지 설명한다. 목적은 복잡한 오케스트레이션 시스템을 만드는 것이 아니라, 수업 과제에 맞게 **설명 가능하고 실행 가능한 로컬 자동화 파이프라인**을 구성하는 것이다.

## 2. 구현 원칙

1. Node.js만으로 실행 가능해야 한다.
2. 외부 API 키 없이도 기본 실행이 가능해야 한다.
3. 산출물은 사람이 읽는 마크다운 파일 중심으로 남겨야 한다.
4. 실제 자동화 범위와 수동 설계 범위를 구분해야 한다.
5. `website/`는 시연용 output으로 유지해야 한다.
6. 저장이 필요한 기능은 Google Sheets + Apps Script 구조로 설계하고, 실서비스 백엔드는 범위에서 제외한다.

## 3. 코드 구조

### `src/run-workflow.js`

전체 워크플로의 진입점이다. 각 생성 함수를 순서대로 실행하고, `output/` 폴더의 문서를 갱신한 뒤 검증 요약을 콘솔에 출력한다.

### `src/generate-prd.js`

PRD 기반 산출물 문자열을 생성한다. `output/02-generated-prd.md`에 들어갈 제출용 요약 버전을 만든다.

### `src/generate-workflow.js`

워크플로 문서, 반성 보고서, 최종 제출 메모에 필요한 텍스트 조각을 생성한다.

### `src/generate-website-prompt.js`

시연용 프론트엔드 구축 또는 개선을 위한 AI 지침 문서를 생성한다. 화면 구조, 카피 방향, 링크 유지 원칙, 스타일 가이드를 포함한다.

### `src/validate-output.js`

프론트엔드와 핵심 산출물이 준비되었는지 확인한다. 필수 파일 존재 여부, 핵심 문구, 필수 링크 포함 여부를 검사하고 보고서 마크다운을 생성한다.

### `src/logger.js`

워크플로 단계별 로그 출력을 담당한다.

### `src/utils.js`

공통 상수와 도구 함수가 들어 있다. 링크 데이터, 디렉터리 경로, 파일 쓰기 도우미, 날짜 형식화 함수 등을 포함한다.

### `apps-script/Code.gs`

Google Sheets에 연결되는 Apps Script Web App 샘플이다. 프론트 입력을 받아 시트에 저장하고, 탭 초기화와 기본 응답을 제공한다.

## 4. 실행 흐름

실행 순서는 아래와 같다.

1. 공통 디렉터리 존재 확인
2. 리서치 요약 생성
3. PRD 산출물 생성
4. PRD 반성 보고서 생성
5. 워크플로 산출물 생성
6. 워크플로 반성 보고서 생성
7. 시연용 프론트엔드 생성 지침 생성
8. 검증 보고서 생성
9. 최종 제출 메모 생성
10. 콘솔 요약 출력

## 5. 산출물과 코드 매핑

* `output/01-research-summary.md`: `run-workflow.js` 내 리서치 요약 생성 함수
* `output/02-generated-prd.md`: `generate-prd.js`
* `output/03-prd-reflection-report.md`: `run-workflow.js`
* `output/04-generated-workflow.md`: `generate-workflow.js`
* `output/05-workflow-reflection-report.md`: `generate-workflow.js`
* `output/06-generated-website-prompt.md`: `generate-website-prompt.js`
* `output/07-website-check-report.md`: `validate-output.js`
* `output/08-final-submission-note.md`: `generate-workflow.js`
* `BACKEND_PLAN.md`: 수동 설계 문서
* `DATA_FLOW.md`: 수동 설계 문서

## 6. 프론트엔드 및 저장 구조 전략

프론트엔드는 프레임워크 없이 다음과 같이 구성한다.

* `index.html`: 기본 구조와 소개 섹션
* `styles.css`: 아동 친화적이고 밝은 비주얼 스타일
* `script.js`: 링크 데이터를 바탕으로 카드 UI를 렌더링

저장이 필요한 기능은 다음 구조를 권장한다.

* 프론트 입력 폼
* Apps Script Web App 엔드포인트
* 단일 Google Spreadsheet
* 여러 개의 탭으로 데이터 분리

이 구조를 선택한 이유는 발표와 제출 과정에서 설명이 쉽고, Firebase 없이도 충분히 현실적인 자동화 구조를 보여 줄 수 있기 때문이다.

## 7. 단순화한 부분

본 구현은 실제 LLM 호출이나 자동 리서치 API를 포함하지 않는다. 대신 워크플로에서 생성되어야 하는 결과 형식을 정리하고, 그 결과를 로컬 코드로 재현 가능한 산출물로 남긴다.

본 구현은 실제 Google 서비스와 라이브 연동하지도 않는다. 대신 Apps Script 배포용 코드, 데이터 구조, 수동 설정 절차를 제공한다. 이는 과제 제출 환경에서 가장 설명 가능하고 안정적인 절충안이다.

## 8. 한계

* 실시간 AI 응답 생성은 포함하지 않는다.
* Apps Script의 실제 배포와 권한 설정은 사용자가 Google 계정에서 수행해야 한다.
* 외부 링크의 실제 접속 가능 여부는 확인하지 않는다.

그 대신 본 시스템은 문서 흐름, 파일 구조, 산출물 관리, 저장 구조 설계, 최종 결과 검증이라는 과제 핵심을 충실히 반영한다.
