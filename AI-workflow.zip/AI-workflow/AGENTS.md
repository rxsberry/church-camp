# AGENTS.md

## 프로젝트 목적

이 저장소의 목적은 교회 초등부 여름성경캠프 운영 지원 서비스를 위한 결과물만 만드는 것이 아니라, 그 결과물이 어떤 AI 워크플로를 통해 정리되고 산출되는지까지 명확히 보여 주는 것이다. 따라서 `website/`는 별도 홈페이지 과제를 대체하는 완성 제품이 아니라, 전체 자동화 흐름의 시연용 산출물이다.

## 핵심 규칙

1. workflow 과제와 홈페이지 과제를 혼동하지 않는다.
2. `website/`는 시연용 output으로 설명한다.
3. 구현하지 않은 자동화를 구현한 것처럼 과장하지 않는다.
4. 문서는 교수자가 빠르게 읽고 구조를 이해할 수 있게 명확하게 작성한다.
5. 사용자 대상 문구는 모두 한국어로 유지한다.
6. `2026 초등부 4~6 믿음 캠프` 문구와 다니엘 중심 주제를 일관되게 유지한다.
7. 제공된 Claude Artifact 링크는 정확히 보존한다.
8. 저장이 필요한 기능은 Google Sheets + Apps Script 구조를 우선한다.

## 에이전트 목록

### 1. Research Agent

프로젝트 배경, 사용 대상, 서비스 목적, 기능군, 디자인 방향을 조사하고 요약한다. 산출물은 `output/01-research-summary.md`이다.

### 2. PRD Agent

리서치 내용을 바탕으로 제품 요구 사항 문서(PRD)를 작성한다. 산출물은 `PRD.md`와 `output/02-generated-prd.md`이다.

### 3. PRD Reviewer Agent

PRD의 누락, 모호함, 범위 과장 여부를 검토하고 반성 보고서를 남긴다. 산출물은 `output/03-prd-reflection-report.md`이다.

### 4. Workflow Architect Agent

PRD를 실제 자동화 파이프라인으로 변환한다. 단계별 입력, 처리, 출력, 검토 루프를 정의한다. 산출물은 `WORKFLOW.md`와 `output/04-generated-workflow.md`이다.

### 5. Workflow Reviewer Agent

워크플로의 실행 가능성, 과제 적합성, 구현 가능성을 검토한다. 산출물은 `output/05-workflow-reflection-report.md`이다.

### 6. Website Builder Agent

워크플로 결과를 시연용 프론트엔드 명세로 바꾸고, 예시 정적 프론트엔드를 구현한다. 산출물은 `output/06-generated-website-prompt.md`와 `website/` 폴더이다.

### 7. Backend Integration Agent

프론트 입력이 Google Sheets로 저장되도록 Apps Script 기반 연동 구조를 설계한다. 산출물은 `BACKEND_PLAN.md`, `DATA_FLOW.md`, `apps-script/` 폴더이다.

### 8. Final Review Agent

모든 문서와 링크, 프론트엔드 노출 문구, 백엔드 설계 문서, 제출 준비 상태를 최종 점검한다. 산출물은 `output/07-website-check-report.md`와 `output/08-final-submission-note.md`이다.

## 작업 원칙

* 파일 이름은 고정적이고 예측 가능해야 한다.
* 결과물은 사람이 읽을 수 있는 마크다운 문서 중심으로 남긴다.
* 복잡한 외부 인프라 없이 제출 가능한 형태를 우선한다.
* 리뷰 단계는 문서 품질과 설명 가능성을 높이기 위한 장치로 사용한다.
* 워크플로는 투명해야 하며, 자동 생성된 결과와 고정 구현된 결과를 구분해 설명해야 한다.
