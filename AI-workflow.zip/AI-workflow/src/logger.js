function logStep(title) {
  console.log(`\n[WORKFLOW] ${title}`);
}

function logDone(message) {
  console.log(`  - ${message}`);
}

module.exports = {
  logStep,
  logDone
};
