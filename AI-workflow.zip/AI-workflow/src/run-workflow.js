const path = require("path");
const { generatePrdOutput } = require("./generate-prd");
const {
  generateWorkflowOutput,
  generateWorkflowReflection,
  generateSubmissionNote
} = require("./generate-workflow");
const { generateWebsitePrompt } = require("./generate-website-prompt");
const { writeValidationReport } = require("./validate-output");
const { OUTPUT_DIR, writeText, today } = require("./utils");
const { logStep, logDone } = require("./logger");

function generateResearchSummary() {
  return `
# 리서치 요약

작성일: ${today()}

## 1. 프로젝트 맥락

이 과제는 교회 초등부 여름성경캠프 운영 지원 서비스를 주제로 하지만, 실제 평가 포인트는 완성된 웹사이트 하나보다 그것을 만들어 내는 AI 워크플로의 구조를 보여 주는 데 있다.

## 2. 핵심 요구

* 리서치부터 최종 검증까지 단계가 보여야 한다.
* PRD, 워크플로, 코딩 계획, 사용자 매뉴얼이 포함되어야 한다.
* 시연용 프론트엔드는 워크플로의 예시 결과물이어야 한다.
* 저장이 필요한 기능은 Google Sheets + Apps Script 구조로 설명 가능해야 한다.
* 모든 사용자 노출 문구는 한국어여야 한다.

## 3. 사용자 집단

* 교수자: 저장소 구조와 설명 가능성을 평가
* 학생 팀: 과제 제출 및 발표
* 교사/봉사자/학부모: 실제 운영 지원 구조 이해
* 초등학생: 캠프 활동 참여

## 4. 콘텐츠 전략

프론트엔드 output은 다니엘의 믿음 이야기를 중심으로 캠프 정체성을 설명하고, 캠프 전/중/후에 필요한 AI 도구를 한곳에 모은다.

## 5. 디자인 전략

* 밝고 친근한 색상
* 둥근 카드
* 명확한 섹션 분리
* 모바일 친화적 구성

## 6. 구현 전략

* 문서 중심 제출 구조
* Node.js 기반 로컬 산출물 생성
* 시연용 정적 프론트엔드 유지
* Google Sheets + Apps Script 저장 구조 제안
* 최종 검증 보고서 자동 생성
`.trim();
}

function generatePrdReflection() {
  return `
# PRD 반성 보고서

## 점검 목적

PRD가 과제 요구를 빠뜨리지 않았는지, 구현 범위를 과장하지 않았는지 확인한다.

## 확인 결과

* 문제 정의와 목표가 분명하다.
* 프론트엔드 기능과 워크플로 기능이 구분되어 있다.
* 실제 구현하지 않는 서버형 AI 시스템을 주장하지 않는다.
* 한국어 문구와 다니엘 주제가 일관되게 반영되어 있다.
* Google Sheets + Apps Script가 현실적 저장 대안으로 정리되어 있다.

## 보완 포인트

* 향후 확장 가능성과 현재 범위를 더 분명히 나눌 필요가 있다.
* 링크 검증 범위가 문자열 포함 수준이라는 점을 계속 명시해야 한다.

## 결론

현재 PRD는 제출용 문서로 충분히 설득력이 있으며, 구현 범위도 정직하게 유지하고 있다.
`.trim();
}

function run() {
  logStep("산출물 생성 시작");

  writeText(path.join(OUTPUT_DIR, "01-research-summary.md"), generateResearchSummary());
  logDone("리서치 요약 생성");

  writeText(path.join(OUTPUT_DIR, "02-generated-prd.md"), generatePrdOutput());
  logDone("PRD 산출물 생성");

  writeText(path.join(OUTPUT_DIR, "03-prd-reflection-report.md"), generatePrdReflection());
  logDone("PRD 반성 보고서 생성");

  writeText(path.join(OUTPUT_DIR, "04-generated-workflow.md"), generateWorkflowOutput());
  logDone("워크플로 산출물 생성");

  writeText(path.join(OUTPUT_DIR, "05-workflow-reflection-report.md"), generateWorkflowReflection());
  logDone("워크플로 반성 보고서 생성");

  writeText(path.join(OUTPUT_DIR, "06-generated-website-prompt.md"), generateWebsitePrompt());
  logDone("시연용 프론트엔드 지침 생성");

  const validation = writeValidationReport();
  logDone("검증 보고서 생성");

  writeText(path.join(OUTPUT_DIR, "08-final-submission-note.md"), generateSubmissionNote());
  logDone("최종 제출 메모 생성");

  logStep("최종 요약");
  console.log(`  - 출력 파일 점검: ${validation.summary.passedFiles}/${validation.summary.totalFiles}`);
  console.log(`  - 백엔드 설계 파일 점검: ${validation.summary.passedRootFiles}/${validation.summary.totalRootFiles}`);
  console.log(`  - 링크 점검: ${validation.summary.passedLinks}/${validation.summary.totalLinks}`);
  console.log(`  - 웹사이트 파일 존재: ${validation.summary.websiteExists ? "예" : "아니오"}`);
  console.log(`  - 제목 문구 확인: ${validation.summary.titleCheck ? "예" : "아니오"}`);
  console.log(`  - 다니엘 주제 확인: ${validation.summary.danielCheck ? "예" : "아니오"}`);
}

run();
