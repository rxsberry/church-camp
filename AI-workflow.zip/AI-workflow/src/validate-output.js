const fs = require("fs");
const path = require("path");
const { OUTPUT_DIR, WEBSITE_DIR, allToolLinks, today, writeText } = require("./utils");

const REQUIRED_FILES = [
  "01-research-summary.md",
  "02-generated-prd.md",
  "03-prd-reflection-report.md",
  "04-generated-workflow.md",
  "05-workflow-reflection-report.md",
  "06-generated-website-prompt.md",
  "08-final-submission-note.md"
];

const REQUIRED_ROOT_FILES = [
  "BACKEND_PLAN.md",
  "DATA_FLOW.md",
  "apps-script/Code.gs",
  "apps-script/appsscript.json"
];

function validateProject() {
  const projectRoot = path.join(__dirname, "..");
  const indexPath = path.join(WEBSITE_DIR, "index.html");
  const scriptPath = path.join(WEBSITE_DIR, "script.js");
  const websiteExists = fs.existsSync(indexPath);
  const indexContent = websiteExists ? fs.readFileSync(indexPath, "utf8") : "";
  const scriptContent = fs.existsSync(scriptPath) ? fs.readFileSync(scriptPath, "utf8") : "";
  const combinedContent = `${indexContent}\n${scriptContent}`;

  const fileChecks = REQUIRED_FILES.map((name) => ({
    name,
    exists: fs.existsSync(path.join(OUTPUT_DIR, name))
  }));

  const rootChecks = REQUIRED_ROOT_FILES.map((name) => ({
    name,
    exists: fs.existsSync(path.join(projectRoot, name))
  }));

  const titleCheck = combinedContent.includes("2026 초등부 4~6 믿음 캠프");
  const danielCheck = combinedContent.includes("다니엘");
  const linkChecks = allToolLinks().map((link) => ({
    link,
    exists: combinedContent.includes(link)
  }));

  const passedFiles = fileChecks.filter((item) => item.exists).length;
  const passedRootFiles = rootChecks.filter((item) => item.exists).length;
  const passedLinks = linkChecks.filter((item) => item.exists).length;

  const report = `
# 웹사이트 및 산출물 검증 보고서

검증일: ${today()}

## 1. 출력 파일 존재 여부

${fileChecks.map((item) => `* ${item.exists ? "통과" : "실패"} - ${item.name}`).join("\n")}

## 1-2. 백엔드 설계 파일 존재 여부

${rootChecks.map((item) => `* ${item.exists ? "통과" : "실패"} - ${item.name}`).join("\n")}

## 2. 시연용 프론트엔드 핵심 문구 점검

* ${titleCheck ? "통과" : "실패"} - 상단 제목에 \`2026 초등부 4~6 믿음 캠프\` 포함
* ${danielCheck ? "통과" : "실패"} - 소개 문구에 다니엘 주제 포함

## 3. 링크 포함 점검

* 총 링크 수: ${linkChecks.length}
* 포함된 링크 수: ${passedLinks}

${linkChecks.map((item) => `* ${item.exists ? "통과" : "실패"} - ${item.link}`).join("\n")}

## 4. 종합 판단

* 출력 파일 통과 수: ${passedFiles}/${fileChecks.length}
* 백엔드 설계 파일 통과 수: ${passedRootFiles}/${rootChecks.length}
* 링크 통과 수: ${passedLinks}/${linkChecks.length}
* 웹사이트 파일 존재: ${websiteExists ? "예" : "아니오"}

현재 검증은 저장소 내부의 파일 존재와 링크 문자열 포함 여부를 기준으로 수행되었다. 외부 사이트의 실제 접속 가능 여부와 Google Apps Script 배포 상태는 이 검증 범위에 포함하지 않는다.
`.trim();

  return {
    report,
    summary: {
      passedFiles,
      totalFiles: fileChecks.length,
      passedRootFiles,
      totalRootFiles: rootChecks.length,
      passedLinks,
      totalLinks: linkChecks.length,
      websiteExists,
      titleCheck,
      danielCheck
    }
  };
}

function writeValidationReport() {
  const result = validateProject();
  writeText(path.join(OUTPUT_DIR, "07-website-check-report.md"), result.report);
  return result;
}

if (require.main === module) {
  const result = writeValidationReport();
  console.log("[VALIDATE] 검증 보고서 생성 완료");
  console.log(
    `[VALIDATE] 출력 파일 ${result.summary.passedFiles}/${result.summary.totalFiles}, 백엔드 설계 파일 ${result.summary.passedRootFiles}/${result.summary.totalRootFiles}, 링크 ${result.summary.passedLinks}/${result.summary.totalLinks}`
  );
}

module.exports = {
  validateProject,
  writeValidationReport
};
