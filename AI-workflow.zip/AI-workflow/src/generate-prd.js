function generatePrdOutput() {
  return `
# 생성된 PRD 산출물

## 프로젝트명

AI Agent Workflow for Church Summer Camp Operations Support

## 핵심 정의

이 프로젝트는 \`2026 초등부 4~6 믿음 캠프\` 운영 지원 서비스를 구조화하는 동시에, 그 결과가 어떤 AI 워크플로 과정을 거쳐 생성되는지 보여 주는 제출형 자동화 시스템이다.

## 문제 요약

과제는 단순한 웹사이트 완성본보다, AI가 조사하고 구조화하고 검토하고 구현하는 과정을 보여 주는 저장소를 요구한다.

## 목표 요약

* 리서치 결과를 문서화한다.
* PRD와 워크플로를 남긴다.
* 시연용 프론트엔드 output과 저장 구조를 결과물로 포함한다.
* 검토 보고서와 제출 메모까지 포함해 설명 가능한 형태로 마무리한다.

## 기능 요약

* 캠프 소개 섹션 제공
* 캠프 전/중/후 링크 허브 제공
* Google Sheets / Apps Script 저장 구조 제안
* 한국어 중심 사용자 경험 제공

## 제약 요약

* 복잡한 백엔드 없이 로컬 실행 가능해야 한다.
* 실제 구현하지 않은 AI 기능을 과장하지 않는다.
* 기존 Artifact 링크를 정확히 유지한다.
`.trim();
}

module.exports = {
  generatePrdOutput
};
