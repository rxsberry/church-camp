function generateWorkflowOutput() {
  return `
# 생성된 워크플로 산출물

## 목적

교회 여름성경캠프 운영 지원 서비스를 위한 기획 문서와 시연용 산출물을 단계형 AI 워크플로 구조로 생성하고 검토하는 것이다.

## 단계 요약

1. 리서치 요약
2. PRD 생성
3. PRD 반성
4. 워크플로 생성
5. 워크플로 반성
6. 시연용 프론트엔드 지침 작성
7. 시연용 프론트엔드 구현 유지
8. Google Sheets / Apps Script 저장 구조 설계
9. 최종 검증 및 제출 메모 작성

## 핵심 특징

* 에이전트 역할 분리
* 문서 중심 산출물
* 시연용 프론트엔드 output 포함
* Google Sheets / Apps Script 기반 저장 구조 제안
* 제출 친화적 구조
`.trim();
}

function generateWorkflowReflection() {
  return `
# 워크플로 반성 보고서

## 잘 된 점

* 문서 흐름이 강의 구조와 일치한다.
* 프론트엔드 output이 워크플로의 예시 결과물로 연결된다.
* Google Sheets / Apps Script 저장 구조가 현실적인 백엔드 대안으로 제시된다.
* 실제 코드가 산출물 생성과 검증을 담당한다.

## 보완이 필요한 점

* 실제 LLM 호출이 없으므로 자동화의 깊이는 제한적이다.
* 프론트와 Apps Script 사이의 실연동은 사용자가 Google 계정에서 직접 배포해야 한다.

## 최종 판단

현재 구조는 제출 과제 기준에서 충분히 설득력 있고, 과장 없이 설명 가능한 로컬 자동화 워크플로로 평가된다.
`.trim();
}

function generateSubmissionNote() {
  return `
# 최종 제출 메모

## 제출 상태 요약

본 저장소는 교회 여름성경캠프 운영 지원을 위한 AI 워크플로 자동화 과제 제출용으로 정리되었다.

## 포함 항목

* 핵심 설계 문서
* 에이전트 역할 문서
* 단계별 프롬프트 문서
* Node.js 워크플로 스크립트
* 출력 산출물 마크다운
* 시연용 프론트엔드
* Google Sheets / Apps Script 연동 설계

## 주의 사항

* 실제 멀티에이전트 서버는 구현하지 않았다.
* 기존 프로토타입 맥락을 정직하게 반영했다.
* 외부 링크는 지정된 Artifact 주소를 유지했다.
* Google 자원 생성과 Apps Script 배포는 사용자 계정에서 수행해야 한다.

## 제출 전 권장 확인

1. \`npm start\` 실행
2. \`output/07-website-check-report.md\` 확인
3. \`website/index.html\` 브라우저 점검
4. \`BACKEND_PLAN.md\`, \`DATA_FLOW.md\`, \`apps-script/Code.gs\` 확인
5. 폴더 전체 압축 후 제출
`.trim();
}

module.exports = {
  generateWorkflowOutput,
  generateWorkflowReflection,
  generateSubmissionNote
};
