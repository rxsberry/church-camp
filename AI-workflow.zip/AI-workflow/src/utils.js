const fs = require("fs");
const path = require("path");

const ROOT_DIR = path.join(__dirname, "..");
const OUTPUT_DIR = path.join(ROOT_DIR, "output");
const WEBSITE_DIR = path.join(ROOT_DIR, "website");

const TOOL_GROUPS = [
  {
    id: "before",
    title: "캠프 전",
    accent: "peach",
    description: "준비 단계에서 필요한 신청, 배치, 홍보, 찬양 관련 도구 모음",
    tools: [
      ["신청폼", "https://claude.ai/public/artifacts/cabaa1d7-b6a2-45f5-be68-708f10ee8742"],
      ["조편성 앱", "https://claude.ai/public/artifacts/b9e77bca-29df-48a4-86ea-fe731d4813ff"],
      ["봉사자 역할 배정", "https://claude.ai/public/artifacts/20928ff6-225c-45fd-a3ea-44f6128c2d1d"],
      ["차량배치", "https://claude.ai/public/artifacts/c5e5a149-12ca-4d5e-b4ea-a89fd3c44bbe"],
      ["준비물 체크", "https://claude.ai/public/artifacts/e271e723-3669-4b1d-9805-32eaeed87970"],
      ["홍보물 제작", "https://claude.ai/public/artifacts/49063846-c297-46fb-84f6-376ecebc821f"],
      ["단체티 디자인", "https://claude.ai/public/artifacts/ee7388fa-1843-448f-8948-e4c5d8b3839e"],
      ["찬양 콘티 생성", "https://claude.ai/public/artifacts/9ee85c7d-3eb4-4312-a6c7-dda36a95ebfb"],
      ["찬양 추천", "https://claude.ai/public/artifacts/8aa91c6b-9280-4f3b-908f-2b43cd86735d"]
    ]
  },
  {
    id: "during",
    title: "캠프 중",
    accent: "sky",
    description: "현장 운영과 게임, 일정 공유, 기도 지원에 필요한 도구 모음",
    tools: [
      ["레크레이션 추천", "https://claude.ai/public/artifacts/4d73e50c-1363-4f7c-8852-924297c1891c"],
      ["성경 음식 퀴즈", "https://claude.ai/public/artifacts/a59a8ae6-e4fb-4cf0-a649-6a98bb4942a9"],
      ["성경 지식 퀴즈", "https://claude.ai/public/artifacts/aa1a3d7f-5047-4dfe-81c8-d5ee38b2ac14"],
      ["사자굴 게임", "https://claude.ai/public/artifacts/8a43b280-657b-4ecb-8cf5-ce0baec3d35c"],
      ["거짓 선지자 찾기", "https://claude.ai/public/artifacts/cd2f1704-730e-4031-a42f-39aa35f59743"],
      ["성경 이모지 게임", "https://claude.ai/public/artifacts/1100559b-b11e-4105-8ae5-70087630b4cd"],
      ["달리기 게임 (예수님 미션 러너)", "https://claude.ai/public/artifacts/4634ae01-db09-4a26-8c69-5597f199c6f0"],
      ["찬양 제목 맞추기 게임", "https://claude.ai/public/artifacts/40475dec-54df-48b0-9a64-1e3502322685"],
      ["기도문 생성", "https://claude.ai/public/artifacts/8eb9c318-8f6a-4cd7-8336-43667c8069bf"],
      ["실시간 스케줄 공유", "https://claude.ai/public/artifacts/f422f1d8-c940-4a5a-b86a-09792603ed8c"],
      ["잃어버린 양 찾기", "https://claude.ai/public/artifacts/5c601695-2158-4b20-831d-d56a4ae9ad1e"]
    ]
  },
  {
    id: "after",
    title: "캠프 후",
    accent: "mint",
    description: "캠프 마무리 후 소감, 정리, 후속 돌봄에 필요한 도구 모음",
    tools: [
      ["소감문", "https://claude.ai/public/artifacts/c73038a2-6442-4469-8492-caa84e8c8780"],
      ["영수증 발급", "https://claude.ai/public/artifacts/1237732c-0ca5-4007-917b-418a7c075b24"],
      ["사진 정리", "https://claude.ai/public/artifacts/21cee897-db83-4e62-86b1-1e783714d30b"],
      ["기도제목 관리", "https://claude.ai/public/artifacts/de4fce15-0280-4dd4-9619-ad3028b9f583"],
      ["포도송이 실천판", "https://claude.ai/public/artifacts/39630fd5-a571-40a1-8bdb-3ab8a80a4f14"]
    ]
  }
];

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function writeText(filePath, content) {
  ensureDir(path.dirname(filePath));
  fs.writeFileSync(filePath, `${content.trim()}\n`, "utf8");
}

function today() {
  return new Date().toISOString().slice(0, 10);
}

function allToolLinks() {
  return TOOL_GROUPS.flatMap((group) => group.tools.map((tool) => tool[1]));
}

module.exports = {
  ROOT_DIR,
  OUTPUT_DIR,
  WEBSITE_DIR,
  TOOL_GROUPS,
  ensureDir,
  writeText,
  today,
  allToolLinks
};
