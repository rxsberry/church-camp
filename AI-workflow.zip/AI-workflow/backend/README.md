# Backend Notes

이 폴더는 교회 여름성경캠프 운영 지원 workflow의 저장 구조 보조 설명을 담는다.

본 프로젝트에서 백엔드는 전통적인 서버가 아니라, 아래 조합을 뜻한다.

* 프론트 입력 폼
* Google Apps Script Web App
* Google Spreadsheet

이 방식은 학생 과제로 구현과 설명이 모두 쉬운 구조다.
