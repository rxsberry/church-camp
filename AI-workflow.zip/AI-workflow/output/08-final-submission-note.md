# 최종 제출 메모

## 제출 상태 요약

본 저장소는 교회 여름성경캠프 운영 지원을 위한 AI 워크플로 자동화 과제 제출용으로 정리되었다.
핵심은 완성형 홈페이지가 아니라, 문서 중심 워크플로와 단계별 산출 구조를 재현 가능하게 제시하는 데 있다.

## 포함 항목

* 핵심 설계 문서
* 에이전트 역할 문서
* 단계별 프롬프트 문서
* Node.js 워크플로 스크립트
* 출력 산출물 마크다운
* 시연용 프론트엔드
* Google Sheets / Apps Script 연동 설계

## 시연물 위치와 역할

* `website/`는 워크플로가 생성/개선한 시연용 frontend output이다.
* Padlet 공유 시 문서 흐름(PRD, WORKFLOW, 검증 보고서)과 함께 설명하는 데 목적이 있다.
* 별도 홈페이지 과제를 대체하는 결과물이 아니라 과제 시연 산출물이다.

## 저장 구조 기준

* Google Sheets 탭 기준: `신청자명단`, `조편성`, `봉사자명단`, `일정메모`, `소감문`, `기도제목`
* 프론트 입력 폼은 Apps Script Web App 엔드포인트를 통해 저장되도록 설계했다.
* `script.js`의 `APPS_SCRIPT_ENDPOINT` 연결 지점을 유지한다.

## 주의 사항

* 실제 멀티에이전트 서버는 구현하지 않았다.
* 기존 프로토타입 맥락을 정직하게 반영했다.
* 외부 링크는 지정된 Artifact 주소를 유지했다.
* Google 자원 생성과 Apps Script 배포는 사용자 계정에서 수행해야 한다.

## 제출 전 권장 확인

1. `npm start` 실행
2. `output/07-website-check-report.md` 확인
3. `website/index.html` 브라우저 점검
4. `BACKEND_PLAN.md`, `DATA_FLOW.md`, `apps-script/Code.gs` 확인
5. Padlet 시연 시 `website/`를 문서 산출물과 함께 설명
6. 폴더 전체 압축 후 제출
