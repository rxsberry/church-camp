# 웹사이트 및 산출물 검증 보고서

검증일: 2026-06-23

## 1. 출력 파일 존재 여부

* 통과 - 01-research-summary.md
* 통과 - 02-generated-prd.md
* 통과 - 03-prd-reflection-report.md
* 통과 - 04-generated-workflow.md
* 통과 - 05-workflow-reflection-report.md
* 통과 - 06-generated-website-prompt.md
* 통과 - 08-final-submission-note.md

## 1-2. 백엔드 설계 파일 존재 여부

* 통과 - BACKEND_PLAN.md
* 통과 - DATA_FLOW.md
* 통과 - apps-script/Code.gs
* 통과 - apps-script/appsscript.json

## 2. 시연용 프론트엔드 핵심 문구 점검

* 통과 - 상단 제목에 `2026 초등부 4~6 믿음 캠프` 포함
* 통과 - 소개 문구에 다니엘 주제 포함
* 통과 - `website/`가 워크플로 시연용 산출물이며 별도 홈페이지 과제를 대체하지 않는다는 설명 포함

## 3. 링크 포함 점검

* 총 링크 수: 25
* 포함된 링크 수: 25

* 통과 - https://claude.ai/public/artifacts/cabaa1d7-b6a2-45f5-be68-708f10ee8742
* 통과 - https://claude.ai/public/artifacts/b9e77bca-29df-48a4-86ea-fe731d4813ff
* 통과 - https://claude.ai/public/artifacts/20928ff6-225c-45fd-a3ea-44f6128c2d1d
* 통과 - https://claude.ai/public/artifacts/c5e5a149-12ca-4d5e-b4ea-a89fd3c44bbe
* 통과 - https://claude.ai/public/artifacts/e271e723-3669-4b1d-9805-32eaeed87970
* 통과 - https://claude.ai/public/artifacts/49063846-c297-46fb-84f6-376ecebc821f
* 통과 - https://claude.ai/public/artifacts/ee7388fa-1843-448f-8948-e4c5d8b3839e
* 통과 - https://claude.ai/public/artifacts/9ee85c7d-3eb4-4312-a6c7-dda36a95ebfb
* 통과 - https://claude.ai/public/artifacts/8aa91c6b-9280-4f3b-908f-2b43cd86735d
* 통과 - https://claude.ai/public/artifacts/4d73e50c-1363-4f7c-8852-924297c1891c
* 통과 - https://claude.ai/public/artifacts/a59a8ae6-e4fb-4cf0-a649-6a98bb4942a9
* 통과 - https://claude.ai/public/artifacts/aa1a3d7f-5047-4dfe-81c8-d5ee38b2ac14
* 통과 - https://claude.ai/public/artifacts/8a43b280-657b-4ecb-8cf5-ce0baec3d35c
* 통과 - https://claude.ai/public/artifacts/cd2f1704-730e-4031-a42f-39aa35f59743
* 통과 - https://claude.ai/public/artifacts/1100559b-b11e-4105-8ae5-70087630b4cd
* 통과 - https://claude.ai/public/artifacts/4634ae01-db09-4a26-8c69-5597f199c6f0
* 통과 - https://claude.ai/public/artifacts/40475dec-54df-48b0-9a64-1e3502322685
* 통과 - https://claude.ai/public/artifacts/8eb9c318-8f6a-4cd7-8336-43667c8069bf
* 통과 - https://claude.ai/public/artifacts/f422f1d8-c940-4a5a-b86a-09792603ed8c
* 통과 - https://claude.ai/public/artifacts/5c601695-2158-4b20-831d-d56a4ae9ad1e
* 통과 - https://claude.ai/public/artifacts/c73038a2-6442-4469-8492-caa84e8c8780
* 통과 - https://claude.ai/public/artifacts/1237732c-0ca5-4007-917b-418a7c075b24
* 통과 - https://claude.ai/public/artifacts/21cee897-db83-4e62-86b1-1e783714d30b
* 통과 - https://claude.ai/public/artifacts/de4fce15-0280-4dd4-9619-ad3028b9f583
* 통과 - https://claude.ai/public/artifacts/39630fd5-a571-40a1-8bdb-3ab8a80a4f14

## 4. 종합 판단

* 출력 파일 통과 수: 7/7
* 백엔드 설계 파일 통과 수: 4/4
* 링크 통과 수: 25/25
* 웹사이트 파일 존재: 예
* 저장 구조 안내: `신청자명단`, `조편성`, `봉사자명단`, `일정메모`, `소감문`, `기도제목` 기준 설명 확인

현재 검증은 저장소 내부의 파일 존재와 링크 문자열 포함 여부를 기준으로 수행되었다. 외부 사이트의 실제 접속 가능 여부와 Google Apps Script 배포 상태는 이 검증 범위에 포함하지 않는다.
