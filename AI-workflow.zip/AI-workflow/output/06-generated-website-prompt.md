# 생성된 시연용 프론트엔드 제작 지침

## 목적

`2026 초등부 4~6 믿음 캠프`를 위한 한국어 시연용 프론트엔드를 제작하거나 개선한다. 이 화면은 다니엘의 믿음 이야기를 중심으로 캠프를 소개하고, 캠프 운영에 필요한 AI 도구 링크를 한곳에 모은 허브여야 한다.

## 필수 카피 방향

* 제목에 `2026`을 크게 노출한다.
* 초등부 4~6학년 대상이라는 점을 분명히 한다.
* 다니엘처럼 어떤 상황에서도 믿음을 지키는 캠프라는 메시지를 담는다.
* 설명 문구는 부모와 교사도 이해하기 쉽게 작성한다.
* 이 화면이 workflow의 시연용 output이라는 점을 명시한다.

## 필수 화면 구조

1. 히어로 섹션
2. 캠프 소개 섹션
4. 캠프 전 도구 섹션
5. 캠프 중 도구 섹션
6. 캠프 후 도구 섹션
7. 안내 및 활용 팁 섹션

## 비주얼 방향

* 밝은 노랑, 하늘색, 민트, 코랄 계열을 활용한다.
* 둥근 카드와 그림자, 부드러운 배경 패턴을 사용한다.
* 아이들에게 친근하지만 정돈된 UI를 유지한다.
* 모바일에서도 카드가 자연스럽게 줄바꿈되도록 한다.

## 링크 정책

* 모든 도구는 새 탭에서 열어야 한다.
* 제공된 Artifact 링크를 그대로 유지해야 한다.
* 버튼이나 카드에 링크 목적이 분명히 드러나야 한다.

## 도구 목록

### 캠프 전

준비 단계에서 필요한 신청, 배치, 홍보, 찬양 관련 도구 모음

* 신청폼: https://claude.ai/public/artifacts/cabaa1d7-b6a2-45f5-be68-708f10ee8742
* 조편성 앱: https://claude.ai/public/artifacts/b9e77bca-29df-48a4-86ea-fe731d4813ff
* 봉사자 역할 배정: https://claude.ai/public/artifacts/20928ff6-225c-45fd-a3ea-44f6128c2d1d
* 차량배치: https://claude.ai/public/artifacts/c5e5a149-12ca-4d5e-b4ea-a89fd3c44bbe
* 준비물 체크: https://claude.ai/public/artifacts/e271e723-3669-4b1d-9805-32eaeed87970
* 홍보물 제작: https://claude.ai/public/artifacts/49063846-c297-46fb-84f6-376ecebc821f
* 단체티 디자인: https://claude.ai/public/artifacts/ee7388fa-1843-448f-8948-e4c5d8b3839e
* 찬양 콘티 생성: https://claude.ai/public/artifacts/9ee85c7d-3eb4-4312-a6c7-dda36a95ebfb
* 찬양 추천: https://claude.ai/public/artifacts/8aa91c6b-9280-4f3b-908f-2b43cd86735d

### 캠프 중

현장 운영과 게임, 일정 공유, 기도 지원에 필요한 도구 모음

* 레크레이션 추천: https://claude.ai/public/artifacts/4d73e50c-1363-4f7c-8852-924297c1891c
* 성경 음식 퀴즈: https://claude.ai/public/artifacts/a59a8ae6-e4fb-4cf0-a649-6a98bb4942a9
* 성경 지식 퀴즈: https://claude.ai/public/artifacts/aa1a3d7f-5047-4dfe-81c8-d5ee38b2ac14
* 사자굴 게임: https://claude.ai/public/artifacts/8a43b280-657b-4ecb-8cf5-ce0baec3d35c
* 거짓 선지자 찾기: https://claude.ai/public/artifacts/cd2f1704-730e-4031-a42f-39aa35f59743
* 성경 이모지 게임: https://claude.ai/public/artifacts/1100559b-b11e-4105-8ae5-70087630b4cd
* 달리기 게임 (예수님 미션 러너): https://claude.ai/public/artifacts/4634ae01-db09-4a26-8c69-5597f199c6f0
* 찬양 제목 맞추기 게임: https://claude.ai/public/artifacts/40475dec-54df-48b0-9a64-1e3502322685
* 기도문 생성: https://claude.ai/public/artifacts/8eb9c318-8f6a-4cd7-8336-43667c8069bf
* 실시간 스케줄 공유: https://claude.ai/public/artifacts/f422f1d8-c940-4a5a-b86a-09792603ed8c
* 잃어버린 양 찾기: https://claude.ai/public/artifacts/5c601695-2158-4b20-831d-d56a4ae9ad1e

### 캠프 후

캠프 마무리 후 소감, 정리, 후속 돌봄에 필요한 도구 모음

* 소감문: https://claude.ai/public/artifacts/c73038a2-6442-4469-8492-caa84e8c8780
* 영수증 발급: https://claude.ai/public/artifacts/1237732c-0ca5-4007-917b-418a7c075b24
* 사진 정리: https://claude.ai/public/artifacts/21cee897-db83-4e62-86b1-1e783714d30b
* 기도제목 관리: https://claude.ai/public/artifacts/de4fce15-0280-4dd4-9619-ad3028b9f583
* 포도송이 실천판: https://claude.ai/public/artifacts/39630fd5-a571-40a1-8bdb-3ab8a80a4f14

## 주의 사항

이 프론트엔드는 본 워크플로 시스템의 시연용 산출물이다. 따라서 별도의 홈페이지 과제를 대체한다고 보이지 않으면서도, AI 도구 활용 허브라는 정체성이 화면 구성에서 드러나야 한다.
