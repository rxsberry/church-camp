# DATA_FLOW.md

## 1. 전체 흐름

```text
사용자 입력
  -> 시연용 프론트 입력 폼
  -> Apps Script Web App
  -> Google Spreadsheet 저장
  -> Apps Script 후처리
  -> 운영용 탭 또는 결과 문서 생성
```

## 2. 신청 정보 흐름

```text
학부모/교사
  -> 신청 입력
  -> doPost()
  -> registrations 탭 저장
  -> 필요 시 teams 탭 생성용 데이터로 사용
```

## 3. 소감문 흐름

```text
학생/학부모
  -> 소감문 입력
  -> doPost()
  -> reflections 탭 저장
  -> 운영진이 후속 정리 가능
```

## 4. 기도제목 흐름

```text
교사/학부모/학생
  -> 기도제목 입력
  -> doPost()
  -> prayer_requests 탭 저장
  -> 카테고리별 정리 가능
```

## 5. 조 편성 흐름

```text
registrations 탭 누적
  -> Apps Script 처리
  -> teams 탭 생성/갱신
  -> 운영진 확인
```

## 6. 권장 최소 배포 구성

* 정적 프론트엔드 1개
* Spreadsheet 1개
* Apps Script Web App 1개

이 구성만으로도 “프론트 입력 → 저장 → 후처리”라는 workflow를 충분히 설명할 수 있다.
